'''
1. Запросите у пользователя число, возведите это число во 2-ю степень и выведите на экран.
'''
user_input = input("Введите число: ")
user_int = int(user_input)

result = user_int ** 2
print("Результат:", result)
